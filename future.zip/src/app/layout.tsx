
// CSS STYLES
import '@/styles/globals.css';

import localFont from 'next/font/local'
import { Metadata } from 'next';
import { addSiteJsonLd } from '@/meta/home';
import { Toaster } from 'react-hot-toast';

const iransans = localFont({
  src: [
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Thin.woff2',
      weight: '100',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-UltraLight.woff2',
      weight: '200',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Light.woff2',
      weight: '300',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Medium.woff2',
      weight: '400',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Regular.woff2',
      weight: '500',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-DemiBold.woff2',
      weight: '600',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Bold.woff2',
      weight: '700',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-ExtraBold.woff2',
      weight: '800',
      style: 'normal',
    },
    {
      path: './../../public/fonts/iransans/woff2/IRANSansX-Black.woff2',
      weight: '900',
      style: 'normal',
    },
  ],
})

const nozha = localFont({
  src: '../../public/fonts/nozha/DigiNozha2Bold.woff2',
  display: 'swap',
  variable: '--font-nozha'
})

export const metadata : Metadata = {
  icons : {
    icon : [
      {
        href : '/favicon.ico',
        url : '/favicon.ico'
      }
    ]
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${iransans.className} ${nozha.variable}`}>
      <body>
        {children}
        <Toaster position="bottom-center"/>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(addSiteJsonLd) }}
        />
      </body>
    </html>
  )
}
