declare module 'persian-number';
