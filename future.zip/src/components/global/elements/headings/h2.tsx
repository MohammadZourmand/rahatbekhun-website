
export interface HeadingsProps {
    cls ?: string,
    text : string,
    color ?: string,
    isNozha ?: boolean,
    center ?: boolean,
    weight ?: string
}

const Heading2 = ({
    cls,
    text,
    color,
    isNozha,
    center,
    weight
} : HeadingsProps) => {

    return (
        <h2
            className={` 
                ${cls}
                ${color ?? "text-gray-700"}
                ${isNozha && "font-nozha"}
                ${!center ? "text-center" : "text-right"}
                ${weight ?? "font-bold"}
                mt-28 lg:text-6xl md:text-6xl sm:text-5xl xs:text-[2.45rem] text-[2.65rem]
            `}>
            {text}
        </h2>
    )
}

export default Heading2;